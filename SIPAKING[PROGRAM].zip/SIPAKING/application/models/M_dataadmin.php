<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dataadmin extends CI_model
{



	public function hitungSemuaDataAdmin()
	{

		return $this->db->get('user')->num_rows();

	}

	//---------------------------------------------------------//
	
	public function tampilDataAdmin($limit, $start)
	{

		return $this->db->get('user', $limit, $start)->result_array();

	}

	//-------------------------------------------------------//
	public function cariDataAdmin()
	{

		$keyword = $this->input->post('keyword', true);
		//jalankan query pencarian
		$this->db->like('name', $keyword);
		$this->db->or_like('email', $keyword);
		return $this->db->get('user')->result_array();


	}





}