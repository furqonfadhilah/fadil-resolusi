<!DOCTYPE html>
<html>
<head>
	<title>Hasil Diagnosa</title>

	<style type="text/css">
		body{
			font: 12px arial, sans-serif;
			color:#333;
		}
        

		.identitas{
		  width: 220px;
		  border: 1px solid black;
		  padding: 1px;
		  margin-top: 4px;
		}

		.kotak{
			width: 220px;
			background-color: salmon;
			color: white;
			text-align: left;
			font-size: 14px;
			font: 12px arial, sans-serif;
		}

		.container{
			width: 690px;
			border: 2px solid #333;
			padding: 5px;
			margin-top: 12px;
		}

		.footer{
			font-size: 9px;
			color: #333;
			margin-top: 100px;
			text-align: center;
		}


    </style>
</head>
<body>


<h2 align="center">SIPAKING - HASIL DIAGNOSA </h2>
<hr>

<div class="identitas">
	<div class="kotak"><b>Form Identitas Konsultasi</b></div>
	<div class="kotak">Nama  : <?= $pdf['nama']?></div>
	<div class="kotak">Email  : <?= $pdf['user_email']?></div>
	<div class="kotak">Tanggal Konsultasi : <?= $pdf['date']?></div>
</div>


<div class="container">
<table>
	<tr>
		<td>No </td>
		<td align="center">Data Gejala<hr></td>
		<td></td>
		<td align="right">Pilihan Gejala </td>
	</tr>
	<?= $i = 1?>
	<?php foreach ($gejala as $g) :?>
	<tr>
		<td> <?= $i ?>.</td>
		<td><?= $g['gejala']?></td>
		<td>:</td>
		
		<td align="right"><?= $pdf['gejala'. $i]?></td>

	</tr>
	<?php $i++?>
<?php endforeach; ?>
</table>


<!-- CETAKAN PENYAKIT KULIT KUCING TERDIAGNOSA -->
<br>
<h3>Kucing Anda Terdiagnosa : <?= $pdf['penyakit'];?></h3>

 <b>PENYEBAB :</b>
	<p><?= $pdf['penyebab'];?></p>

	<br>

	<b>SOLUSI :</b>
	    <p><?= $pdf['solusi'];?></p>
</div>



<p class="footer">Created By Furqon Fadhilah - Sistem Pakar Penyakit Kulit Pada Kucing </p>



</body>
</html>