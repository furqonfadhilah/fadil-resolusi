 <!-- Start Jumbotron -->
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-5 text-center"><marquee>CAT LOVERS - KONSULTASI</marquee></h1>
      </div>
    </div>
    <!-- End Jumbotron -->
    <!-- Start Card -->
    <div class="container">
      <?= form_open();?>
      <div class="row justify-content-md-center">
        <div class="col-md-6">
          <div class="card content">
            <div class="card-header">
              <h3>Form Konsultasi</h3>
            </div>
            <div class="card-body">
              
                <div class="form-group">
                    <label for="exampleInputPassword1">Name*</label>
                    <input type="text" class="form-control" placeholder="Enter Name.." name="nama" value="<?= set_value('nama');?>">
                    <?= form_error('nama','<small class="text-danger pl-3">','</small>'); ?>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Email*</label>
                    <input type="text" class="form-control" placeholder="Enter Email.." name="user_email" value="<?= set_value('user_email');?>">
                    <?= form_error('user_email','<small class="text-danger pl-3">','</small>'); ?>

                </div>
                  <button type="submit" class="btn btn-primary btn-user btn-block">
                    Konsultasi
                    </button>
            </div>
          </div>
        </div>
      </div>


       <?= form_close();?>
    </div>
    <!-- End Card -->

   
   