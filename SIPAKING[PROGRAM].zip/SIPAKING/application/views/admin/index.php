   
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

          <?= $this->session->flashdata('message'); ?>

          <div class="row mt-3>">
          	<div class="col-md-6">
          		<!-- Search -->
          		<form action="" method="post">
					<div class="input-group ">
					  <input type="text" class="form-control" placeholder="Search Data Admin" name="keyword">
					  <div class="input-group-append">
					    <button class="btn btn-primary" type="submit">Search</button>
					  </div>
					</div>
          		</form>
          	</div>
          </div>

          <!-- Jika data yang di cari tidak ditemukan -->
          <?php if(empty($list)): ?>
          	<div class="alert alert-danger" role="alert">
          		Data admin not found!. Please Registration
          	</div>
          <?php endif; ?>



          <!-- MELIHAT DATA ADMIN -->
          <table class="table">
		  <thead class="thead-dark">
		    <tr>
		      <th scope="col">#</th>
		      <th scope="col">Name</th>
		      <th scope="col">E-mail</th>
		      <th scope="col">Role Id</th>
		    </tr>
		  </thead>
		  <tbody>
 			<?php foreach ($list as $l) : ?>
		    <tr>
		      <th scope="row"><?= ++$start; ?></th>
		      <td><?= $l['name']; ?></td>
		      <td><?= $l['email']; ?></td>
		      <td><?php if($l['role_id'] == 1){ 
              echo "<span class='badge badge-success'>Admin</span>";
          	  		} ?></td>
		    </tr>
		    
    		<?php endforeach; ?>
		  </tbody>
		</table>
          
		<?= $this->pagination->create_links(); ?>
				
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

   