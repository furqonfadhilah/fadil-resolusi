   
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

          <?= $this->session->flashdata('message'); ?>

          <div class="row">
           <div class="col-md-3 mb-2">
            <a href="<?= base_url('datalatih/exportexcel') ?>" class="btn btn-success mt-2"><i class="far fa-fw fa-file-excel"></i> Export To Excel </a>
           </div>
          	<div class="col-md-5 mt-2">
          		<!-- Search -->
          		<form action="" method="post">
      					 <div class="input-group ">
      					  <input type="text" class="form-control" placeholder="Search Data Kategori Penyakit" name="keyword">
      					  <div class="input-group-append">
      					    <button class="btn btn-primary" type="submit">Search</button>
      					  </div>
      					 </div>
          		</form>
          	</div>
          </div>

          <!-- Jika data yang di cari tidak ditemukan -->
          <?php if(empty($list)): ?>
          	<div class="alert alert-danger" role="alert">
          		Data kategori penyakit not found!
          	</div>
          <?php endif; ?>

     
      
          <!-- MELIHAT DATA LATIH -->
      <div class="table-responsive">
      <table class="table">
		  <thead class="thead-dark">
		    <tr>
		      <th scope="col">#</th>
		      <th scope="col">G1</th>
		      <th scope="col">G2</th>
		      <th scope="col">G3</th>
          <th scope="col">G4</th>
          <th scope="col">G5</th>
          <th scope="col">G6</th>
          <th scope="col">G7</th>
          <th scope="col">G8</th>
          <th scope="col">G9</th>
          <th scope="col">G10</th>
          <th scope="col">G11</th>
          <th scope="col">G12</th>
          <th scope="col">G13</th>
          <th scope="col">G14</th>
          <th scope="col">G15</th>
          <th scope="col">G16</th>
          <th scope="col">G17</th>
          <th scope="col">G18</th>
          <th scope="col">G19</th>
          <th scope="col">G20</th>
          <th scope="col">Kategori Penyakit</th>
          <th scope="col">Option</th>
		    </tr>
		  </thead>
		  <tbody>
      
 			<?php foreach ($list as $l) : ?>
		    <tr>
		      <th scope="row"><?= ++$start; ?></th>
		      <td><?= $l['gejala1']; ?></td>
		      <td><?= $l['gejala2']; ?></td>
		      <td><?= $l['gejala3']; ?></td>
          <td><?= $l['gejala4']; ?></td>
          <td><?= $l['gejala5']; ?></td>
          <td><?= $l['gejala6']; ?></td>
          <td><?= $l['gejala7']; ?></td>
          <td><?= $l['gejala8']; ?></td>
          <td><?= $l['gejala9']; ?></td>
          <td><?= $l['gejala10']; ?></td>
          <td><?= $l['gejala11']; ?></td>
          <td><?= $l['gejala12']; ?></td>
          <td><?= $l['gejala13']; ?></td>
          <td><?= $l['gejala14']; ?></td>
          <td><?= $l['gejala15']; ?></td>
          <td><?= $l['gejala16']; ?></td>
          <td><?= $l['gejala17']; ?></td>
          <td><?= $l['gejala18']; ?></td>
          <td><?= $l['gejala19']; ?></td>
          <td><?= $l['gejala20']; ?></td>
          <td><?= $l['kategori']; ?></td>
          <td>


            <a href="<?= base_url();?>datalatih/edit_data_latih/<?= $l['kode_datalatih']; ?>" class="badge badge-pill badge-info"> <i class="fas fa-edit"></i> 
            <a href="<?= base_url(); ?>datalatih/hapus_data_latih/<?= $l['kode_datalatih']; ?>" class="badge badge-pill badge-danger" onclick="return confirm('Are your sure for delete this field data training number <?= $l['kode_datalatih']; ?>? ')"><i class="fas fa-trash"></i></a>


          </td>
		    </tr>
    		<?php endforeach; ?>
		</tbody>
		</table>
    </div>  
		
      <?= $this->pagination->create_links(); ?>
				
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

   